import subprocess
import sys

def mathverify(data_source, solution_str, ground_truth, extra_info=None):
    try:
        # 动态导入（首次使用时自动安装）
        try:
            from math_verify import parse, verify
        except ImportError:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "math-verify[antlr4_9_3]", "-i", "https://pypi.tuna.tsinghua.edu.cn/simple"])
            from math_verify import parse, verify
        print("solution_str:", solution_str)
        #print("sol type:", type(solution_str))
        print("===============================")
        print("parse gt:", parse(ground_truth))
        print("parse sol:", parse(solution_str))
        #print("===============================")
        judge = verify(parse(ground_truth), parse(solution_str))
        print("judge:", judge)
        print("===============================")
        return 1. if judge else 0.
        
    except Exception as e:
        print(f"验证失败: {str(e)}")
        return 0.
