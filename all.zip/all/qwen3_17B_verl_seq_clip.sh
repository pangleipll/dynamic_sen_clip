set -x

# we need this to avoid fragmentation of GPU memory
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:256
export TORCH_SHOW_CPP_STACKTRACES=1


export WANDB_BASE_URL="http://10.249.132.30:3008/"
export WANDB_API_KEY=local-0329f9bba8602a0532c5df3099c0cb83bee78148
export WANDB_OFFICIAL=1
export WANDB_MODE=online

gsm8k_train_path=/workspace/workspace/data/grpo0711/train.parquet
gsm8k_test_path=/workspace/workspace/data/grpo0711/test.parquet
train_files="['$gsm8k_train_path']"
test_files="['$gsm8k_test_path']"
reward_func_path=/workspace/workspace/verl/verl/my_reward.py
model_path=/workspace/workspace/data/checkpoints/models--Qwen--Qwen3-8B-Base/snapshots/49e3418fbbbca6ecbdf9608b4d22e5a407081db4
# RAY_ADDRESS='http://127.0.0.1:8265' 
# ray job submit --working-dir ./ \
#  --runtime-env=verl/trainer/runtime_env.yaml \
#  --no-wait \
#  -- \
# compute-sanitizer --tool memcheck --leak-check no --target-processes all --log-file out.%p.txt \
python3 -m verl.trainer.main_ppo --config-path=config \
    --config-name='ppo_megatron_trainer.yaml'\
    algorithm.adv_estimator=grpo \
    data.train_files="$train_files" \
    data.val_files="$test_files" \
    data.train_batch_size=128 \
    data.max_prompt_length=2000 \
    data.max_response_length=18000 \
    data.filter_overlong_prompts=True \
    data.truncation='error' \
    actor_rollout_ref.model.use_remove_padding=True \
    actor_rollout_ref.model.path=$model_path \
    actor_rollout_ref.actor.optim.lr=1e-6 \
    actor_rollout_ref.actor.use_dynamic_bsz=True \
    actor_rollout_ref.actor.ppo_max_token_len_per_gpu=40000 \
    actor_rollout_ref.rollout.log_prob_max_token_len_per_gpu=40000 \
    actor_rollout_ref.ref.log_prob_max_token_len_per_gpu=40000 \
    actor_rollout_ref.actor.policy_loss.loss_mode=seq_clip \
    actor_rollout_ref.actor.ppo_mini_batch_size=32 \
    actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=32 \
    actor_rollout_ref.actor.megatron.tensor_model_parallel_size=8 \
    actor_rollout_ref.actor.loss_agg_mode="token-mean" \
    actor_rollout_ref.actor.megatron.param_offload=True \
    actor_rollout_ref.actor.megatron.grad_offload=True \
    actor_rollout_ref.actor.megatron.optimizer_offload=True \
    actor_rollout_ref.actor.clip_ratio_high=0.03 \
    actor_rollout_ref.actor.clip_ratio_low=1 \
    actor_rollout_ref.actor.use_kl_loss=False \
    actor_rollout_ref.actor.kl_loss_coef=0.00 \
    actor_rollout_ref.actor.kl_loss_type=low_var_kl \
    actor_rollout_ref.actor.entropy_coeff=0 \
    algorithm.filter_groups.enable=True \
    algorithm.filter_groups.max_num_gen_batches=10 \
    algorithm.filter_groups.metric=acc \
    actor_rollout_ref.rollout.max_num_batched_tokens=4096 \
    actor_rollout_ref.rollout.max_num_seqs=1200 \
    actor_rollout_ref.model.enable_gradient_checkpointing=True \
    actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=16 \
    actor_rollout_ref.rollout.tensor_model_parallel_size=8 \
    actor_rollout_ref.rollout.name=vllm \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.5 \
    actor_rollout_ref.rollout.n=16 \
    actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=32 \
    actor_rollout_ref.ref.megatron.param_offload=True \
    algorithm.use_kl_in_reward=False \
    trainer.critic_warmup=0 \
    trainer.logger=['console','wandb'] \
    trainer.project_name='megatron_vllm_qwen3_1_7B' \
    trainer.experiment_name='qwen3_1.7b_seq_no_lower' \
    trainer.n_gpus_per_node=8 \
    trainer.nnodes=1 \
    trainer.save_freq=10 \
    trainer.test_freq=4 \
    trainer.total_epochs=1 \
    trainer.default_local_dir=/workspace/workspace/verl/qwen3_1.7b_seq_no_lower \
    custom_reward_function.path="$reward_func_path" \
    custom_reward_function.name=mathverify $@ > test_output.log 2>&1
